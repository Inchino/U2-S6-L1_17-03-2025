﻿namespace S6_L1.ViewModels
{
    public class StudenteListViewModel
    {
        public List<StudenteViewModel> Studenti { get; set; } = new List<StudenteViewModel>();
    }

}
